<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>  
<head>
<meta charset="UTF-8">
<title>
  Notifikasi | Tutorial Simple Login Register CodeIgniter @ http://recodeku.blogspot.com
</title>
</head>
<body>
<h3><?php echo $message; ?></h3>
 <p><?php echo anchor('beranda','Kembali ke beranda'); ?></p>
</body>
</html>
