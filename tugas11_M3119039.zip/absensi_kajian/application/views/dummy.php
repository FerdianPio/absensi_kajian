<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<?php
		echo $nama_perwakilan;
		echo $tingkat;
		echo $ketua;
echo $sekertaris;
echo $bendahara;
echo $alamat_perwakilan;
echo $cp_perwakilan;
echo "<br>";
// foreach ($id as $key => $value) {
// 	//echo $key."as key and".$value."as value";
// 	echo $value['id_pengurus'];
// }
// echo "<br>";
echo $id_pengurus;
	?>
</body>
</html>
